package eu.epfc.mypocketmovie.view;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

import eu.epfc.mypocketmovie.R;
import eu.epfc.mypocketmovie.controller.PocketMoviesAdapter;
import eu.epfc.mypocketmovie.controller.RecentMoviesAdapter;
import eu.epfc.mypocketmovie.model.Movie;
import eu.epfc.mypocketmovie.model.MovieDetail;
import eu.epfc.mypocketmovie.model.PocketMovieManager;



public class PocketMovieFragment extends MovieFragment {

    static final String TAG = "PocketMovieFragment";

    public PocketMovieFragment() {
        // Required empty public constructor
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_pocket_movie, container, false);

    }

    @Override
    public void onStart(){
        super.onStart();

        movies = new ArrayList<>();
        moviesRecyclerView = getView().findViewById(R.id.list_pocket_movies);
        moviesRecyclerView.setItemViewCacheSize(0);
        // set the adapter of the RecyclerView
        moviesAdapter = new PocketMoviesAdapter(this);
        moviesRecyclerView.setAdapter(moviesAdapter);

        // set the layoutManager of the recyclerView
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        moviesRecyclerView.setLayoutManager(layoutManager);


        loadMovieData();
    }

    void loadMovieData(){
        PocketMovieManager movieManager= PocketMovieManager.getInstance();
        movies=movieManager.getAllMovies();
        PocketMoviesAdapter moviesAdapter = new PocketMoviesAdapter(this);
        moviesAdapter.setMovieData(movies);
    }

}
