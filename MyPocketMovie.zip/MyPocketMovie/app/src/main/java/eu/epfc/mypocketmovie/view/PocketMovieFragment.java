package eu.epfc.mypocketmovie.view;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

import eu.epfc.mypocketmovie.R;
import eu.epfc.mypocketmovie.controller.PocketMoviesAdapter;
import eu.epfc.mypocketmovie.controller.RecentMoviesAdapter;
import eu.epfc.mypocketmovie.model.Movie;
import eu.epfc.mypocketmovie.model.MovieDetail;
import eu.epfc.mypocketmovie.model.PocketMovieManager;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link PocketMovieFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link PocketMovieFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class PocketMovieFragment extends Fragment {
    private RecyclerView moviesRecyclerView;
    private List< Movie> movies;
    private int pageNb=1;
    private MovieDetail selectedMovieDetail;
    static final String TAG = "PocketMovieFragment";

    public PocketMovieFragment() {
        // Required empty public constructor
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_pocket_movie, container, false);

    }

    @Override
    public void onStart(){
        super.onStart();

        movies = new ArrayList<>();
        moviesRecyclerView = getView().findViewById(R.id.list_recent_movies);
        moviesRecyclerView.setItemViewCacheSize(0);
        // set the adapter of the RecyclerView
        PocketMoviesAdapter pocketMoviesAdapter = new PocketMoviesAdapter();
        moviesRecyclerView.setAdapter(pocketMoviesAdapter);

        // set the layoutManager of the recyclerView
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        moviesRecyclerView.setLayoutManager(layoutManager);


        loadMovieData();
    }

    void loadMovieData(){
        PocketMovieManager movieManager= PocketMovieManager.getInstance();
        movies=movieManager.getAllMovies();
        PocketMoviesAdapter moviesAdapter = new PocketMoviesAdapter();
        moviesAdapter.setMovieData(movies);
    }

}
