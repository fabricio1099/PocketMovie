package eu.epfc.mypocketmovie.view;

import android.app.FragmentTransaction;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import eu.epfc.mypocketmovie.R;
import eu.epfc.mypocketmovie.controller.RecentMoviesAdapter;
import eu.epfc.mypocketmovie.model.HttpRequestService;
import eu.epfc.mypocketmovie.model.Movie;
import eu.epfc.mypocketmovie.model.PocketMovieManager;

public class MainActivity extends AppCompatActivity {
    private Fragment currentFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
/*DEBUG_SWITCH_ADDED_180611*/           setContentView(R.layout.activity_main);
/*DEBUG_SWITCH_RETIRED_180611*///        onCreatePopulateFromInternet();
        if (findViewById(R.id.recent_movie_fragment_container) != null) {

            // However, if we're being restored from a previous state,
            // then we don't need to do anything and should return or else
            // we could end up with overlapping fragments.
            if (savedInstanceState != null) {
                return;
            }

            // Create a new Fragment to be placed in the activity layout
            RecentMovieFragment firstFragment = new RecentMovieFragment();

            // In case this activity was started with special instructions from an
            // Intent, pass the Intent's extras to the fragment as arguments
            firstFragment.setArguments(getIntent().getExtras());

            // Add the fragment to the 'fragment_container' FrameLayout
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.recent_movie_fragment_container, firstFragment).commit();
        }
    }

    public void setCurrentFragment(Fragment currentFragment){
        this.currentFragment=currentFragment;
    }
    protected void trailerVideo(View view){
        ((MovieDetailFragment) currentFragment).trailerVideo(currentFragment.getView());
    }
    protected void onCheckBoxClicked(View view){
        ((MovieDetailFragment) currentFragment).onCheckBoxClicked(currentFragment.getView());
    }


    protected void nextPage(View view){
        ((RecentMovieFragment) ((MovieFragment) currentFragment)).nextPage(view);
    }
    protected void previousPage(View view){
        ((RecentMovieFragment) currentFragment).previousPage(view);
    }
    protected void switchToFragment(android.app.Fragment newFragment){
        FragmentTransaction transaction = getFragmentManager().beginTransaction();
        transaction.replace(R.id.recent_movie_fragment_container, newFragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

}
