package eu.epfc.mypocketmovie.view;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import eu.epfc.mypocketmovie.R;
import eu.epfc.mypocketmovie.controller.RecentMoviesAdapter;
import eu.epfc.mypocketmovie.model.HttpRequestService;
import eu.epfc.mypocketmovie.model.Movie;
import eu.epfc.mypocketmovie.model.PocketMovieManager;

public class MainActivity extends AppCompatActivity {
    private Fragment currentFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
/*DEBUG_SWITCH_ADDED_180611*/           setContentView(R.layout.activity_main);
/*DEBUG_SWITCH_RETIRED_180611*///        onCreatePopulateFromInternet();
    }

    public void setCurrentFragment(Fragment currentFragment){
        this.currentFragment=currentFragment;
    }
    protected void trailerVideo(View view){
        ((DetailFragment) currentFragment).trailerVideo(currentFragment.getView());
    }
    protected void onCheckBoxClicked(View view){
        ((DetailFragment) currentFragment).onCheckBoxClicked(currentFragment.getView());
    }


    protected void nextPage(View view){
        ((RecentMovieFragment) currentFragment).nextPage(view);
    }
    protected void previousPage(View view){
        ((RecentMovieFragment) currentFragment).previousPage(view);
    }

}
